import React, { useEffect, useState } from "react";

function App() {
  const [location, setLocation] = useState(null);

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Geolocation error:", error);
        }
      );
    } else {
      console.error("Geolocation not supported.");
    }
  };

  useEffect(() => {
    getUserLocation();
  }, []);

  return (
    <div>
      <h1>Cinema Finder</h1>
      {location ? (
        <p>Your location: {location.lat}, {location.lng}</p>
      ) : (
        <p>Detecting location...</p>
      )}
    </div>
  );
}

export default App;
